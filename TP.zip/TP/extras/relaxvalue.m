function x = relaxvalue(x)
%RELAXVALUE (overloaded sdpvar/relaxvalue on double)

% Do nothing, just return input.