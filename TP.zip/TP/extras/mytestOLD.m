function y = mytestOLD(X,B)

y = B - X*X;