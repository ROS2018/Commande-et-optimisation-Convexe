%Ex7

A= [-0.1 -1 0;1 0 0;0 1 0];
B=[2;0;0];
a = -1; b = -2; t= pi/8;

U = [-a 0; 0 b]
Q1 = [0.5 0 ; 0 -0.5];
Q2 = [sin(t) cos(t); -cos(t) sin(t)];

X=sdpvar(3,3,'symmetric');
W = sdpvar(1,3,'full');

L1 = kron(U,X)+ kron(Q1,A*X+B*W) + kron(Q1',X*A'+W'*B')<0;
L2 = kron(Q2,A*X+B*W) + kron(Q2',X*A'+W'*B')<0;

solvesdp(L1+L2);
X = double(X)
K = double(W)*X
%%
poles=eig(A+B*K)
plot(poles,'o')