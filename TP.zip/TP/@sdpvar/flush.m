function x = flush(x)
x.leftfactors = [];
x.rightfactors = [];
x.midfactors = [];
