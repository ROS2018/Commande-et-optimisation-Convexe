function varargout = log2(varargin)
%log2 (overloaded)

varargout{1} = log(varargin{1})/log(2);