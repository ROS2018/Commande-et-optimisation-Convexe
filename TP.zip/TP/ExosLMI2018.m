clc
clear all
close all
 warning off
%%% exemple 3bis: pendule simple (stabilit�) Yalmip+Sedumi
% Le syst�me stationnaire
A = [0 1;-1 -2]; % pour g/l=4/3 et n=2

% D�claration de la LMI
P = sdpvar(2,2,'symmetric')
L1 = P*A+A'*P<0;
L2=P>0
% LMI_PP = set(P*A+A'*P<0)+ set(P>0);
LMI_PP=L1+L2;
s=solvesdp(LMI_PP,[],sdpsettings('solver','lmilab'))
double(P)
eig(double(P))
% 
% %break
% 
% % % R�solution du probl�me de faisabilit�
% % [tmin,xfeas] = feasp(Stab);
% % % Extraction du r�sultat
% % P_opt=dec2mat(Stab,xfeas,P)
% 
% Analyse de stabilit� d'un syst�me polytopique 
A1 = [0 1;-1 -2];
A2 = [0 1;-3 -5];
A3 = [0 1;-5 -10];

% D�claration de la LMI
setlmis([])

P=lmivar(1,[2 1]);

lmiterm([-1 1 1 P],1,1)
lmiterm([-1 1 2 0],0)
lmiterm([-1 1 3 0],0)
lmiterm([-1 1 4 0],0)
lmiterm([-1 2 2 P],-1,A1,'s')
lmiterm([-1 2 3 0],0)
lmiterm([-1 2 4 0],0)
lmiterm([-1 3 3 P],-1,A2,'s')
lmiterm([-1 3 4 0],0)
lmiterm([-1 4 4 P],-1,A3,'s')

Stab_polytope=getlmis;

% R�solution du probl�me de faisabilit�
[tmin,xfeas] = feasp(Stab_polytope);    

% Etraction du r�sultat
P_opt=dec2mat(Stab_polytope,xfeas,P)
% 
% %%% Exemple4 : cas du pendule 
% % Calcul du taux de d�croissance d'un syst�me LTI
% A = [0 1;-1 -2]; %Le pendule simple
% 
% % D�claration de la LMI
% setlmis([])
% 
% P=lmivar(1,[2 1]);
% Y=lmivar(1,[2 1]);
% 
% lmiterm([1 1 1 P],-1,1)
% 
% lmiterm([2 1 1 P],A',1,'s')
% lmiterm([-2 1 1 Y],2,1)
% 
% lmiterm([3 1 1 Y],1,1)
% lmiterm([-3 1 1 P],1,1)
% 
% Taux_de_decroissance=getlmis;
% 
% % R�solution du probl�me de minimisation de valeur propre g�n�ralis�e
% options = [1e-10,0,0,0,0];
% [tmin,xopt] = gevp(Taux_de_decroissance,1,options);
% 
% alpha = - tmin
% 
% break
% 
% %%%exemple 5 : calcul de norm Hinf
% % Le syst�me 
% A = [-2 0;-1 -1];
% B = [1;0];
% C = [0 1];
% D = 1;
% sys = ltisys(A,B,C,D);
% % calcul de la norme hinfini (utilisation d'une formulation LMI) 
% 
% setlmis([])
% 
% P=lmivar(1,[2 1]);
% t=lmivar(1,[1 0]);
% 
% lmiterm([1 1 1 P],1,A,'s')
% lmiterm([1 1 1 0],C'*C)
% lmiterm([1 1 2 P],1,B)
% lmiterm([1 1 2 0],C'*D)
% lmiterm([1 2 2 0],D'*D)
% lmiterm([1 2 2 t],-1,1)
% 
% lmiterm([-2 1 1 P],1,1)
% lmiterm([-2 1 2 0],0)
% lmiterm([-2 2 2 t],1,1)
% 
% 
% lmihf=getlmis;
% 
% options = [1e-9,0,0,0,0];
%     [cout_opt,value_opt]=mincx(lmihf,[0 0 0 1],options);
%     
% P_opt=dec2mat(lmihf,value_opt,P)
% hinf_norm2=sqrt(dec2mat(lmihf,value_opt,t))
% hinf_norm1 = hinfnorm(sys)
% 
% %%%exemple 6
% % Le syst�me 
% A = [-2 0;-1 -1];
% B = [1;0];
% C = [0 1];
% D = 0;
% sys = ltisys(A,B,C,D);
% 
% % calcul de la norme h2 (utilisation d'une formulation LMI) 
% 
% setlmis([])
% 
% P=lmivar(1,[2 1]);
% Q=lmivar(1,[1 0]);
% 
% lmiterm([1 1 1 P],1,A,'s')
% lmiterm([1 1 2 0],C')
% lmiterm([1 2 2 0],-1)
% 
% lmiterm([-2 1 1 Q],1,1)
% lmiterm([-2 1 2 P],B',1)
% lmiterm([-2 2 2 P],1,1)
% 
% 
% lmih2=getlmis;
% 
% n=decnbr(lmih2);
% c=zeros(n,1);
% for j=1:n
%    [Pj,Qj]=defcx(lmih2,j,P,Q);
%    c(j)=trace(Qj);
% end;
% options = [1e-9,0,0,0,0];
%     [cout_opt,value_opt]=mincx(lmih2,c,options);
%     
% P_opt=dec2mat(lmih2,value_opt,P)
% h2_norm2=sqrt(dec2mat(lmih2,value_opt,Q))
% h2_norm1=normH2(sys)
% 
% 
% %%%exemple 7 : stabilisation par retour d'�tat
% A =[-0.1 -1 0; 1 0 0;0 1 0];
% B =[2;0;0]
% 
% setlmis([])
% 
% X=lmivar(1,[3 1]);
% W=lmivar(2,[1 3]);
% 
% lmiterm([-1 1 1 X],1,1)
% lmiterm([2 1 1 X],A,1,'s')
% lmiterm([2 1 1 W],B,1,'s')
% 
% Stabilisation=getlmis;
% 
% % R�solution du probl�me de faisabilit�
% [tmin,xfeas] = feasp(Stabilisation);
% 
% K = dec2mat(Stabilisation,xfeas,W)*inv(dec2mat(Stabilisation,xfeas,X))
% 
% %%%exemple 8 : Placement de p�les dans une r�gion LMI
% 
% A =[-0.1 -1 0; 1 0 0;0 1 0];B =[2;0;0];
% alpha1 = -1; alpha2 = -2; t = pi/8;
% U = [-alpha1 0;0 alpha2];
% Q1 = [1/2 0;0 -1/2];
% Q2 = [sin(t) cos(t);-cos(t) sin(t)];
% 
% X = sdpvar(3,3,'symmetric')
% W = sdpvar(1,3,'full');
% 
% LMI_PP = set([kron(U,X)+kron(Q1,A*X+B*W)+kron(Q1',X*A'+W'*B')<0])...
%     + set([kron(Q2,A*X+B*W)+kron(Q2',X*A'+W'*B')<0])+ set(X>0);
% s=solvesdp(LMI_PP,[],sdpsettings('solver','sedumi'))
% K = double(W)*inv(double(X))
% 
% %%% exemple 9 : �quivalence H2-RE et LQ
% A =[-0.1 -1 0; 1 0 0;0 1 0];B =[2;0;0];
% r=1;
% x0 = [1;-1;2];
% 
% %%% LQ/Riccati 
% Q = eye(3);
% R = r;
% [Klq,Xlq,E] = lqr(A,B,Q,R);
% J1 = sqrt(x0'*Xlq*x0)
% Klq
% 
% 
% %%% LQ/LMI 
% C1 = [sqrt(Q);zeros(1,3)];
% D12 = [zeros(3,1);sqrt(R)];
% B2 = B;
% B1 = x0;
% 
% 
% setlmis([])
% 
% P = lmivar(1,[3 1]);
% W = lmivar(2,[1 3]);
% Y = lmivar(1,[4 1]);
% 
% lmiterm([1 1 1 P],A,1,'s')
% lmiterm([1 1 1 W],-B2,1,'s')
% lmiterm([1 1 1 0],B1*B1')
% 
% lmiterm([-2 1 1 Y],1,1)
% lmiterm([-2 1 2 P],C1,1)
% lmiterm([-2 1 2 W],-D12,1)
% lmiterm([-2 2 2 P],1,1)
%     
%     lmi0 = getlmis; 
%     nr = decnbr(lmi0);
%     cout = zeros(nr,1);
% 
%     for k=1:nr
%         [Pk,Wk,Yk] = defcx(lmi0,k,P,W,Y);
%         cout(k) = trace(Yk);
%         end
% 
%     [cout_opt,value_opt] = mincx(lmi0,cout,[1e-6,1e3,0,0,1]);
% 
%         P = dec2mat(lmi0,value_opt,P);
% 
%         W = dec2mat(lmi0,value_opt,W);
%         
%         JH2 = sqrt(cout_opt)
%         KH2 = W*inv(P)
% 
% %%% exemple 10 : synth�se mixte H2 Hinf
% A = [0 1;-1 0];B = [0;1];C=[0 1];
% C1 = [1 0;0 0]; B1 = [1 0;0 1];
% C2 = [0 1]; B2 = [1;0];
% D1u = [0;1];D2u =0;
% g=1.42;
% X = sdpvar(2,2,'symmetric')
% W = sdpvar(1,2,'full');
% Z = sdpvar(2,2,'symmetric');
% 
% lmi1 = set([X*A'+A*X+B*W+W'*B' (C1*X+D1u*W)';C1*X+D1u*W -eye(2)]<0);
% lmi2 = set([Z B1';B1 X]>0);
% lmi3 = set([X*A'+A*X+B*W+W'*B' B2 (C2*X+D2u*W)';B2' -g 0;C2*X+D2u*W 0 -g]<0);
% 
% lmi_mixte = lmi1+lmi2+lmi3;
% 
% solvesdp(lmi_mixte,trace(Z),sdpsettings('solver','sedumi'));
% 
% h2=sqrt(trace(double(Z)))
% 

%% exercices supl. 
clear all;
close all;
clc

x0 = [1;.1];
A = [0 1;-1 0];
B = [0;1];
C = [1 0;0 0];
D = [0;1];

R = 1;
Q = [1 0;0 0];

[Kare,Pare,~] = lqr(A,B,Q,R)
x0'*Pare*x0


options = [1e-6,1e3,0,0,0];

setlmis([])

P = lmivar(1,[2 1]);

lmiterm([-1 1 1 P],1,1)

lmiterm([-2 1 1 P],A',1,'s')
lmiterm([-2 1 1 0],C'*C)
lmiterm([-2 1 2 P],1,B)
lmiterm([-2 2 2 0],D'*D)

     lmi0 = getlmis;
     nr = decnbr(lmi0);
     cout = zeros(nr,1);

     for k=1:nr
         [Pk] = defcx(lmi0,k,P);
         cout(k) = -(x0'*Pk*x0);
         end

     [cout_opt,value_opt] = mincx(lmi0,cout,options);

         Popt = dec2mat(lmi0,value_opt,P);
         J = -cout_opt
         K = inv(D'*D)*B'*Popt



