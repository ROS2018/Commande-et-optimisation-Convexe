
%% Robustness and stability
A1=[0 1 ;-1 -2];
A2=[0 1 ;-3 -5];
A3=[0 1 ;-5 -10];
p=sdpvar(2,2)
L0=p>0;
L1= p*A1+A1'*p<0;
L2= p*A2+A2'*p<0;
L3= p*A3+A3'*p<0;
L=L0+L1+L2+L3;
optimize(L);
%s=solvesdp(L)

double(p) 

 
%% Stablization:
clc;clear all;
A = [-0.1 -1 0; 1 0 0; 0 1 0];
B = [2; 0; 0];
X = sdpvar(3,3);
W = sdpvar(1,3);
L0 = X>0 ;
L1 = X*A'+A*X+W'*B'+B*W<0;
solvesdp(L0+L1);
P = inv(double(X))
K = double(W)*P

%% H2 par LMI
A = [-0.1 -1 0; 1 0 0; 0 1 0];
B = [2; 0; 0];
C = eye(3);
P = sdpvar(3,3);
L0 = P>0;
L1 = A*P+P*A'+B*B'<0 ; 
solvesdp(L0+L1,trace(C*P*C'));
double(P)

%% Stabilit� robust garante (lemme r�el born�)
A = [0 1 0 0; 0 0 1 0; 0 0 0 1 ; -3 -6 -10 -2];
B = [0 0 0 -1 ]';
C = [1 2 0 0];
P = sdpvar(4,4);
g = sdpvar(1,1);
% g = 3;
L0 = P>0;
L1 = [A'*P+P*A P*B  C'
      B'*P    -g  0
      C         0   -g]<0;
  solvesdp(L1+L0,g);
  e= 1/double(g)
  double(P)
  
 %% stabilit� robust:
 clear all, clc;
 
%  s =-1000;%sdpvar(1,1); 
 %DA =[0 0 0 0; 0 0 0 0; 0 0 0 0 ; -s -2*s 0 0];
 A = [0 1 0 0; 0 0 1 0; 0 0 0 1 ; 3 6 10 2];
 
 %Ad = A+DA;
 P = sdpvar(4,4);
 L0 = P>0;
 L1 = (A'*P+P*A) <0;
solvesdp(L0+L1)
% double(s)
P=double(P)
eig(A)
x=diag(eye(4))
Ppos=x'*P*x

Ly=x'*(A'*P+P*A)*x
 % problem de calcul numerique, il faut changer le solveur
%%
A = [-0.1 -1 0;1 0 0; 0 1 0]; B = [2 0 0]';
 